
/**
 * This class creates a HashSet of Items in the game that have a name, description, and a weight.
 * Some items will be equipable while others will stay mounted in the room they are placed in.
 * 
 * @author (Alex Liossis) 
 * @version (03.17.17)
 */
public class Item
{
    private String name;
    private String description;
    private double weight;
    private boolean equipable;

    /**
     * 
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public String getName()
    {
         this.name = name;
        return name; 
    }
    
    public String getDescription()
    {
        this.description = description;
        return description;
    }
    
    //Something to set weights on objects public void setWeight(double weight)
    {
        ;
    }
    
    public void checkEquip()
    {
        if(weight<(20.0))
        {
            equipable = true;
        }
    }
    
    
}
